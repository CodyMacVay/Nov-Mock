<?php
echo "<div class='nav'>";
    echo "<nav>";
        echo "<ul>";
            echo "<li> <a href='index.php'>Home</a></li>";
            echo "<li> <a href='register.php'>Register</a></li>";
        echo "</ul>";
    echo "</nav>";
echo "</div>";

?>

